"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBDAOFactory = void 0;
const DynamoDBUserDAO_1 = require("../implementations/dynamo/DynamoDBUserDAO");
const DynamoDBStatusDAO_1 = require("../implementations/dynamo/DynamoDBStatusDAO");
const DynamoDBFollowDAO_1 = require("../implementations/dynamo/DynamoDBFollowDAO");
const DynamoDBSessionDAO_1 = require("../implementations/dynamo/DynamoDBSessionDAO");
const S3DAO_1 = require("../implementations/s3/S3DAO");
class DynamoDBDAOFactory {
    userDAO = new DynamoDBUserDAO_1.DynamoDBUserDAO();
    statusDAO = new DynamoDBStatusDAO_1.DynamoDBStatusDAO();
    followDAO = new DynamoDBFollowDAO_1.DynamoDBFollowDAO();
    s3DAO = new S3DAO_1.S3DAO();
    sessionDAO = new DynamoDBSessionDAO_1.DynamoDBSessionDAO();
    getUserDAO() { return this.userDAO; }
    getStatusDAO() { return this.statusDAO; }
    getFollowDAO() { return this.followDAO; }
    getS3DAO() { return this.s3DAO; }
    getSessionDAO() { return this.sessionDAO; }
}
exports.DynamoDBDAOFactory = DynamoDBDAOFactory;
