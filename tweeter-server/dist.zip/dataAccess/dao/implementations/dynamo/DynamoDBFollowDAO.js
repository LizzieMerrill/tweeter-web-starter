"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBFollowDAO = void 0;
const AWS = __importStar(require("aws-sdk"));
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });
const FOLLOWS_TABLE = process.env.FOLLOWS_TABLE || "follows";
const USERS_TABLE = process.env.USERS_TABLE || "users";
class DynamoDBFollowDAO {
    async getFollowers(userAlias, pageSize, lastItem) {
        const params = {
            TableName: FOLLOWS_TABLE,
            KeyConditionExpression: "followeeAlias = :alias",
            ExpressionAttributeValues: { ":alias": userAlias },
            Limit: pageSize
        };
        if (lastItem && lastItem.alias) {
            params.ExclusiveStartKey = {
                followeeAlias: userAlias,
                followerAlias: lastItem.alias
            };
        }
        const result = await docClient.query(params).promise();
        const records = (result.Items || []);
        const [converted, hasMore] = await this.convertAliasesToUserDtos(records, "followerAlias", result.LastEvaluatedKey);
        return [converted, hasMore];
    }
    async getFollowees(userAlias, pageSize, lastItem) {
        const params = {
            TableName: FOLLOWS_TABLE,
            KeyConditionExpression: "followerAlias = :alias",
            ExpressionAttributeValues: { ":alias": userAlias },
            Limit: pageSize
        };
        if (lastItem && lastItem.alias) {
            params.ExclusiveStartKey = {
                followerAlias: userAlias,
                followeeAlias: lastItem.alias
            };
        }
        const result = await docClient.query(params).promise();
        const records = (result.Items || []);
        const [converted, hasMore] = await this.convertAliasesToUserDtos(records, "followeeAlias", result.LastEvaluatedKey);
        return [converted, hasMore];
    }
    async follow(followerAlias, followeeAlias) {
        const putFollowees = {
            TableName: FOLLOWS_TABLE,
            Item: { followerAlias, followeeAlias },
            ConditionExpression: "attribute_not_exists(followerAlias) AND attribute_not_exists(followeeAlias)"
        };
        const putFollowers = {
            TableName: FOLLOWS_TABLE,
            Item: { followeeAlias, followerAlias },
            ConditionExpression: "attribute_not_exists(followeeAlias) AND attribute_not_exists(followerAlias)"
        };
        await Promise.all([
            docClient.put(putFollowees).promise(),
            docClient.put(putFollowers).promise()
        ]);
    }
    async unfollow(followerAlias, followeeAlias) {
        const delFollowees = { TableName: FOLLOWS_TABLE, Key: { followerAlias, followeeAlias } };
        const delFollowers = { TableName: FOLLOWS_TABLE, Key: { followeeAlias, followerAlias } };
        await Promise.all([
            docClient.delete(delFollowees).promise(),
            docClient.delete(delFollowers).promise()
        ]);
    }
    async convertAliasesToUserDtos(records, aliasField, lastEvaluatedKey) {
        if (records.length === 0) {
            return [[], !!lastEvaluatedKey];
        }
        const aliases = records.map((r) => r[aliasField]);
        const uniqueAliases = Array.from(new Set(aliases));
        const batchParams = {
            RequestItems: {
                [USERS_TABLE]: {
                    Keys: uniqueAliases.map((alias) => ({ alias }))
                }
            }
        };
        const response = await docClient.batchGet(batchParams).promise();
        const userItems = response.Responses ? response.Responses[USERS_TABLE] : [];
        const userMap = {};
        for (const u of userItems || []) {
            userMap[u.alias] = u;
        }
        const userDtos = [];
        for (const record of records) {
            const aliasVal = record[aliasField];
            if (userMap[aliasVal]) {
                userDtos.push(userMap[aliasVal]);
            }
        }
        return [userDtos, !!lastEvaluatedKey];
    }
}
exports.DynamoDBFollowDAO = DynamoDBFollowDAO;
