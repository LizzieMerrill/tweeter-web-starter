"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBSessionDAO = void 0;
const AWS = __importStar(require("aws-sdk"));
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });
const AUTH_TOKENS_TABLE = process.env.AUTH_TOKENS_TABLE || "auth_tokens";
class DynamoDBSessionDAO {
    async createSession(token, alias, expiresAt, lastActivity) {
        const params = {
            TableName: AUTH_TOKENS_TABLE,
            Item: {
                token,
                alias,
                expiresAt,
                lastActivity
            },
            ConditionExpression: "attribute_not_exists(token)"
        };
        await docClient.put(params).promise();
    }
    async getSession(token) {
        const params = {
            TableName: AUTH_TOKENS_TABLE,
            Key: { token }
        };
        const result = await docClient.get(params).promise();
        return result.Item ? result.Item : null;
    }
    async updateSessionActivity(token, lastActivity, newExpiresAt) {
        let updateExpression = "set lastActivity = :la";
        const expressionAttributeValues = { ":la": lastActivity };
        if (newExpiresAt) {
            updateExpression += ", expiresAt = :ea";
            expressionAttributeValues[":ea"] = newExpiresAt;
        }
        const params = {
            TableName: AUTH_TOKENS_TABLE,
            Key: { token },
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: expressionAttributeValues
        };
        await docClient.update(params).promise();
    }
    async deleteSession(token) {
        const params = {
            TableName: AUTH_TOKENS_TABLE,
            Key: { token }
        };
        await docClient.delete(params).promise();
    }
}
exports.DynamoDBSessionDAO = DynamoDBSessionDAO;
