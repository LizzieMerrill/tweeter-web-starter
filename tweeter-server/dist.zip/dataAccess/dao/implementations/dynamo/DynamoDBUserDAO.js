"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDBUserDAO = void 0;
// src/dataAccess/dao/implementations/dynamo/DynamoDBUserDAO.ts
const AWS = __importStar(require("aws-sdk"));
const bcrypt = __importStar(require("bcryptjs"));
const tweeter_shared_1 = require("tweeter-shared");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const docClient = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });
const USERS_TABLE = process.env.USERS_TABLE || "users";
// For this implementation we use the followees table to check if a user is following another:
const FOLLOWS_TABLE = process.env.FOLLOWS_TABLE || "follows";
class DynamoDBUserDAO {
    async getUserByAlias(alias) {
        const params = {
            TableName: USERS_TABLE,
            Key: { alias }
        };
        const result = await docClient.get(params).promise();
        return result.Item ? result.Item : null;
    }
    async login(alias, password) {
        const user = await this.getUserByAlias(alias);
        if (!user) {
            throw new Error("User not found or invalid alias");
        }
        const storedHash = user.hashedPassword;
        if (!storedHash) {
            throw new Error("Password not set for this user");
        }
        const valid = await bcrypt.compare(password, storedHash);
        if (!valid) {
            throw new Error("Invalid password");
        }
        const authToken = tweeter_shared_1.AuthToken.Generate();
        return { user, authToken };
    }
    async register(firstName, lastName, alias, password, userImageUrl) {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = {
            alias,
            firstName,
            lastName,
            hashedPassword, // stored for password verification
            imageUrl: userImageUrl, // mapped as needed in your domain
            createdAt: new Date().toISOString(),
            followerCount: 0,
            followeeCount: 0
        };
        const params = {
            TableName: USERS_TABLE,
            Item: newUser,
            ConditionExpression: "attribute_not_exists(alias)"
        };
        await docClient.put(params).promise();
        const authToken = tweeter_shared_1.AuthToken.Generate();
        // Exclude hashedPassword from the returned user object
        const { hashedPassword: _, ...userDto } = newUser;
        return { user: userDto, authToken };
    }
    async updateFollowCounts(alias, followerCount, followeeCount) {
        const params = {
            TableName: USERS_TABLE,
            Key: { alias },
            UpdateExpression: "set followerCount = :fc, followeeCount = :fe",
            ExpressionAttributeValues: {
                ":fc": followerCount,
                ":fe": followeeCount
            }
        };
        await docClient.update(params).promise();
    }
    // Implement getIsFollowerStatus by checking if the user (userAlias) follows the selected user (selectedUserAlias)
    async getIsFollowerStatus(userAlias, selectedUserAlias) {
        // Using the followees table: if userAlias is following selectedUserAlias, an item should exist.
        const params = {
            TableName: FOLLOWS_TABLE,
            Key: {
                followerAlias: userAlias,
                followeeAlias: selectedUserAlias
            }
        };
        const result = await docClient.get(params).promise();
        return !!result.Item;
    }
    // Verify a password using bcrypt
    async verifyPassword(user, password) {
        const storedHash = user.hashedPassword;
        if (!storedHash) {
            throw new Error("User's password hash not available");
        }
        return await bcrypt.compare(password, storedHash);
    }
    // Get follower count from the user record
    async getFollowerCount(alias) {
        const user = await this.getUserByAlias(alias);
        if (!user) {
            throw new Error("User not found");
        }
        return user.followerCount || 0;
    }
    // Get followee count from the user record
    async getFolloweeCount(alias) {
        const user = await this.getUserByAlias(alias);
        if (!user) {
            throw new Error("User not found");
        }
        return user.followeeCount || 0;
    }
}
exports.DynamoDBUserDAO = DynamoDBUserDAO;
