"use strict";
// import * as AWS from "aws-sdk";
// import { IS3DAO } from "../../interfaces/IS3DAO";
// import { Buffer } from "buffer";
// import * as dotenv from 'dotenv';
// dotenv.config();
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3DAO = void 0;
// const s3 = new AWS.S3({ region: "us-east-1" });
// const S3_BUCKET = process.env.S3_BUCKET || "cs340milestone3lizziemerrill";
// export class S3DAO implements IS3DAO {
//   async uploadProfileImage(
//     userAlias: string,
//     imageBuffer: Buffer,
//     fileExtension: string
//   ): Promise<string> {
//     const fileKey = `profile-images/${userAlias}.${fileExtension}`;
//     const contentType = fileExtension === "png" ? "image/png" : "image/jpeg";
//     const params: AWS.S3.PutObjectRequest = {
//       Bucket: S3_BUCKET,
//       Key: fileKey,
//       Body: imageBuffer,
//       ContentType: contentType,
//       ACL: "public-read"
//     };
//     await s3.putObject(params).promise();
//     return `https://${S3_BUCKET}.s3.amazonaws.com/${fileKey}`;
//   }
// }
const AWS = __importStar(require("aws-sdk"));
const s3 = new AWS.S3({ region: "us-east-1" });
const S3_BUCKET = process.env.S3_BUCKET || "cs340milestone3lizziemerrill";
class S3DAO {
    async uploadProfileImage(userAlias, imageBuffer, fileExtension) {
        const fileKey = `profile-images/${userAlias}.${fileExtension}`;
        const contentType = fileExtension === "png" ? "image/png" : "image/jpeg";
        const params = {
            Bucket: S3_BUCKET,
            Key: fileKey,
            Body: imageBuffer,
            ContentType: contentType,
            ACL: "public-read"
        };
        await s3.putObject(params).promise();
        return `https://${S3_BUCKET}.s3.amazonaws.com/${fileKey}`;
    }
    // Optionally, add a method to generate a pre-signed URL:
    async generatePreSignedUploadUrl(fileKey, contentType) {
        const params = {
            Bucket: S3_BUCKET,
            Key: fileKey,
            Expires: 60, // URL valid for 60 seconds
            ContentType: contentType,
            ACL: "public-read"
        };
        return s3.getSignedUrlPromise("putObject", params);
    }
}
exports.S3DAO = S3DAO;
