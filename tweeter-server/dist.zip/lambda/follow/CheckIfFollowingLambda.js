"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../model/service/UserService");
const DynamoDBDAOFactory_1 = require("../../dataAccess/dao/factory/DynamoDBDAOFactory");
const daoFactory = new DynamoDBDAOFactory_1.DynamoDBDAOFactory();
const handler = async (request) => {
    const userService = new UserService_1.UserService(daoFactory.getUserDAO(), daoFactory.getS3DAO(), daoFactory.getFollowDAO(), daoFactory.getSessionDAO());
    const follower = await userService.getIsFollowerStatus(request.token, request.user, request.selectedUser);
    return {
        success: true,
        message: undefined,
        follower: follower
    };
};
exports.handler = handler;
