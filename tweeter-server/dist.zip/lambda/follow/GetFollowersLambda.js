"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../model/service/FollowService");
const DynamoDBDAOFactory_1 = require("../../dataAccess/dao/factory/DynamoDBDAOFactory");
const daoFactory = new DynamoDBDAOFactory_1.DynamoDBDAOFactory();
const handler = async (request) => {
    const followService = new FollowService_1.FollowService(daoFactory.getFollowDAO());
    const [items, hasMore] = await followService.loadMoreFollowers(request.token, request.userAlias, request.pageSize, request.lastItem);
    return {
        success: true,
        message: undefined,
        items,
        hasMore
    };
};
exports.handler = handler;
