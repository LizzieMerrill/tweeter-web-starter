"use strict";
// import { FakeData, User, UserDto } from "tweeter-shared";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
class FollowService {
    followDAO;
    constructor(followDAO) {
        this.followDAO = followDAO;
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        return await this.followDAO.getFollowers(userAlias, pageSize, lastItem);
    }
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        return await this.followDAO.getFollowees(userAlias, pageSize, lastItem);
    }
}
exports.FollowService = FollowService;
