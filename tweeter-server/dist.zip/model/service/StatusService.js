"use strict";
// import { FakeData, Status, StatusDto } from "tweeter-shared";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
class StatusService {
    statusDAO;
    constructor(statusDAO) {
        this.statusDAO = statusDAO;
    }
    // Load story items using the DAO.
    async loadMoreStoryItems(token, userAlias, pageSize, lastItem) {
        return await this.statusDAO.loadStory(userAlias, pageSize, lastItem);
    }
    // Load feed items using the DAO.
    async loadMoreFeedItems(token, userAlias, pageSize, lastItem) {
        return await this.statusDAO.loadFeed(userAlias, pageSize, lastItem);
    }
    // Post a status update.
    async postStatus(token, newStatus) {
        await this.statusDAO.postStatus(newStatus);
    }
}
exports.StatusService = StatusService;
