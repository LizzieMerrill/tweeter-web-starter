"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
class UserService {
    //login
    async login(alias, password) {
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid alias or password");
        }
        return [user.dto, tweeter_shared_1.FakeData.instance.authToken];
    }
    ;
    //logout
    async logout(token) {
        // Pause so we can see the logging out message. Delete when the call to the server is implemented.
        await new Promise((res) => setTimeout(res, 1000));
    }
    ;
    //register
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        //**************DID BELOW COMMENTED OUT STEP IN CLIENT-SIDE USERSERVICE!!!***************
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        // const imageStringBase64: string =
        //   Buffer.from(userImageBytes).toString("base64");
        // TODO: Replace with the result of calling the server
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid registration");
        }
        return [user.dto, tweeter_shared_1.FakeData.instance.authToken];
    }
    ;
    //getuser for usernavigationhook
    async getUser(token, alias) {
        // TODO: Replace with the result of calling server
        const user = (tweeter_shared_1.FakeData.instance.findUserByAlias(alias));
        return user.dto == null ? null : user.dto;
    }
    ;
    //follow
    async follow(token, userToFollow) {
        // Pause so we can see the follow message. Remove when connected to the server
        return await this.getCounts(token, userToFollow);
    }
    ;
    //unfollow
    async unfollow(token, userToUnfollow) {
        // Pause so we can see the unfollow message. Remove when connected to the server
        return await this.getCounts(token, userToUnfollow);
    }
    ;
    async getCounts(token, userToUnfollow) {
        await new Promise((f) => setTimeout(f, 2000));
        // TODO: Call the server
        const followerCount = await this.getFollowerCount(token, userToUnfollow);
        const followeeCount = await this.getFolloweeCount(token, userToUnfollow);
        return [followerCount, followeeCount];
    }
    //user info
    async getIsFollowerStatus(token, user, selectedUser) {
        // TODO: Replace with the result of calling server
        return tweeter_shared_1.FakeData.instance.isFollower();
    }
    ;
    //more user info
    async getFolloweeCount(token, user) {
        // TODO: Replace with the result of calling server
        return tweeter_shared_1.FakeData.instance.getFolloweeCount(user.alias);
    }
    ;
    //oh look, even more user info
    async getFollowerCount(token, user) {
        // TODO: Replace with the result of calling server
        return tweeter_shared_1.FakeData.instance.getFollowerCount(user.alias);
    }
    ;
}
exports.UserService = UserService;
